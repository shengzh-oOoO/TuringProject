# TuringProject

编译方法:

g++ turing-project/turing.cpp -o turing
